===========
LED Flasher
===========

This example periodically toggles the on-board LED marked as LED0.

Drivers
-------
* GPIO
* Delay
