Filelist:
SAML21_Xplained_Pro_layer_plots_release_rev4.pdf : PCB Layer Plots
SAML21_Xplained_Pro_design_documentation_release_rev4.pdf : Design Documentation
SAML21_Xplained_Pro_PCB_stackup_rev4.pdf : PCB stackup used in the design.
BOM\Bill of Materials Print- SAML21_Xplained_Pro_release_rev4.xls : BOM, fitted components
CAD Source\* : Altium project source files
ExportSTEP\SAML21_Xplained_Pro_release_rev4.step : 3D Model of PCBA
Gerber\SAML21_Xplained_Pro_release_rev4.GP1 : Gerber files for GND
Gerber\SAML21_Xplained_Pro_release_rev4.GP2 : Gerber files for POWER
Gerber\SAML21_Xplained_Pro_release_rev4.GM1 : Gerber files for Mechanical 1
Gerber\SAML21_Xplained_Pro_release_rev4.GBO : Gerber files for Bottom Overlay
Gerber\SAML21_Xplained_Pro_release_rev4.GBL : Gerber files for Bottom Layer LF-signals
Gerber\SAML21_Xplained_Pro_release_rev4.GBS : Gerber files for Bottom Solder
Gerber\SAML21_Xplained_Pro_release_rev4.GBP : Gerber files for Bottom Paste
Gerber\SAML21_Xplained_Pro_release_rev4.GTL : Gerber files for Top Layer LF-signals
Gerber\SAML21_Xplained_Pro_release_rev4.GTO : Gerber files for Top Overlay
Gerber\SAML21_Xplained_Pro_release_rev4.GTP : Gerber files for Top Paste
Gerber\SAML21_Xplained_Pro_release_rev4.GTS : Gerber files for Top Solder
NC Drill\SAML21_Xplained_Pro_release_rev4.drl : Drill files, gerber
NC Drill\SAML21_Xplained_Pro_release_rev4.drr : Drill Files Report
ODB\SAML21_Xplained_Pro_release_rev4.zip : ODB++ Files
Pick Place\Pick Place for SAML21_Xplained_Pro_release_rev4.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for SAML21_Xplained_Pro_release_rev4.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for SAML21_Xplained_Pro_release_rev4.csv : Assembly Testpoint report, csv
NC Drill\SAML21_Xplained_Pro_release_rev4.LDP : Layer Pairs Definition
NC Drill\SAML21_Xplained_Pro_-SlotHoles_release_rev4.txt : Drill files, ASCII-SlotHoles
NC Drill\SAML21_Xplained_Pro_-RoundHoles_release_rev4.txt : Drill files, ASCII-RoundHoles
